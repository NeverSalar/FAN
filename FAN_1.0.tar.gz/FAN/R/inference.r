# methods with estimation / testing

inference_all_in_one = function(dat, d = NULL, choosing_maximum = NULL, max_Z3 = 10){
	P1 = matrix(1 / dat$n, nrow = dat$n, ncol = dat$n)
	In = diag(rep(1, dat$n))

    # determine dimension of z_{12}
    if(is.null(d)){
        if(is.null(choosing_maximum)){
            choosing_maximum = dat$p
        }
        d = choose_dimension(dat$A, n = choosing_maximum, plot = FALSE)
    }
    # estimate network model via spectral embedding
	Xhat = spec_emb(dat$A, d = d)
	Xhat = correct_sign(Xhat)
	Z12hat = (In - P1) %*% Xhat
	# DIAGOLALIZE Z
	eigen_Z = eigen(t(Z12hat) %*% Z12hat)
	Z12hat = Z12hat %*% eigen_Z$vectors

	# estimate factor model via spectral embedding
	L12hat = t(solve(t(Z12hat) %*% Z12hat) %*% t(Z12hat) %*% (In - P1) %*% dat$Y)
	Rhat = (In - Z12hat %*% solve(t(Z12hat) %*% Z12hat) %*% t(Z12hat)) %*% (In - P1) %*% dat$Y

	# test number of Z_3
	eigenvals_CovR = eigen(cov(Rhat))$values
	No_Z3_series = sapply(0 : max_Z3, function(o){
	test_Z3(eigenvals_CovR, k0 = o, diff = 1)$output})
	for(i in 1 : (max_Z3 - 1)){
		if(No_Z3_series[i] == FALSE & No_Z3_series[i + 1] == TRUE){
			Num_Z3 = i
			break
		}
		Num_Z3 = 0
	}
	# if there's no Z_3
	if (Num_Z3 == 0){
		Psihat = diag(diag(cov(Rhat)))
		Lhat = L12hat
	} else{
		fac_res = factor.analysis(Rhat, Num_Z3, method = "ml")
		sigmas = fac_res$Sigma
		Z3hat = fac_res$Z
		eigen_Z3 = eigen(t(Z3hat) %*% Z3hat)
		Z3hat = Z3hat %*% eigen_Z3$vectors
		Psihat = diag(sigmas)
		Lhat = cbind(L12hat, fac_res$Gamma)
	}
	# IDENTIFIABILITY OF L AND PSI
	ic_mat = t(Lhat) %*% solve(Psihat) %*% Lhat / dat$p
	eigen_m = eigen(ic_mat)
	Lhat = Lhat %*% eigen_m$vectors
	# test number of Z_1
	Num_Z1 = test_Z1(Z12hat, L12hat[, 1 : dim(L12hat)[2]], diag(Psihat))$output
	
	return(list(Num_Z1 = Num_Z1, Num_Z3 = Num_Z3, Z12hat = Z12hat, Z3hat = Z3hat, Lhat = Lhat))
}

spec_emb = function(A, d){
	# get d-dim embedding from adj-matrix
	spec_full = eigen(t(A) %*% A)
	U = spec_full$vectors[, 1 : d]
	D = diag(sqrt(sqrt(round(spec_full$values[1 : d], 6))), nrow = d)
	return(U %*% D)
}

correct_sign = function(X){
	# correct signs for each column of X
	for(j in 1 : dim(X)[2])
		if(X[1 , j] < 0)
			X[, j] = - X[, j]
	return(X)
}

correct_rotation = function(X){
	# correct roration of X to let t(X) %*% X to be diagonal
	Xv = svd(X)$v
	return(X %*% Xv)
}

test_Z3 = function(eigenvals, k0 = 0, diff = 1, level = "ninety_five"){
	# test whether Z3 exist or not with diff = 1
	# can test dimension of Z3 by setting diff = k3
	# return TRUE if H0 is accepted
	quantile_table = list(ninety_five = c(6.89, 12.41, 18.16, 23.99, 29.41, 35.05, 39.89, 47.35), ninety_nine = c(16.56, 28.75, 41.57, 55.07, 67.53, 79.13, 91.90, 106.01))
	# quantile values are referred to Onatski's 2008 paper
	ratio = (eigenvals[1 + k0] - eigenvals[diff + 1 + k0]) / (eigenvals[diff + 1 + k0] - eigenvals[diff + 2 + k0])
	return(list(output = ratio < quantile_table[[level]][diff], level = level, ratio = ratio))
}


test_Z1 = function(Z12hat, L12hat, sigmas, level = 0.05){
	k12 = dim(L12hat)[2]
	p = dim(L12hat)[1]
	V = matrix(0, nrow = p, ncol = k12)
	for (j in 1 : p){
		sigma_j = sigmas[j]
		for (k in 1 : k12){
			V[j, k] = sigma_j * diag(solve(t(Z12hat) %*% Z12hat))[k]
		}
	}
	S = rep(0, k12)
	for (k in 1 : k12){
		S[k] = (sum((L12hat[, k])^2) - sum(V[, k])) / sqrt(2 * sum((V[, k])^2))
	}
	return(list(S = S, output = sum(abs(S) < qnorm(1 - level / 2))))
}


test_Z1_permute = function(Y, Z12hat, L12hat, sigmas, level = 0.05, rounds = 500){
	# test Z1 with permutation method
	k12 = dim(Z12hat)[2]
	p = dim(Y)[2]
	n = dim(Y)[1]
	P1 = matrix(1 / n, nrow = n, ncol = n)
	In = diag(rep(1, n))

	V = matrix(0, nrow = p, ncol = k12)
	for (j in 1 : p){
		sigma_j = sigmas[j]
		for (k in 1 : k12){
			V[j, k] = sigma_j * diag(solve(t(Z12hat) %*% Z12hat))[k]
		}
	}
	S = rep(0, k12)
	for (k in 1 : k12){
		S[k] = (sum((L12hat[, k])^2) - sum(V[, k])) / sqrt(2 * sum((V[, k])^2))
	}

	res_S = sapply(1 : rounds, function(o){
		# y = apply(Y, 2, sample)
		series = sample(1 : n)
		y = Y[series, ]
		L12hat_perm = t(solve(t(Z12hat) %*% Z12hat) %*% t(Z12hat) %*% (In - P1) %*% y)
		# Rhat = (In - Z12hat %*% solve(t(Z12hat) %*% Z12hat) %*% t(Z12hat)) %*% (In - P1) %*% dat$Y
		V = matrix(0, nrow = p, ncol = k12)
		for (j in 1 : p){
			sigma_j = sigmas[series[j]]
			for (k in 1 : k12){
				V[j, k] = sigma_j * diag(solve(t(Z12hat) %*% Z12hat))[k]
			}
		}
		S = rep(0, k12)
		for (k in 1 : k12){
			S[k] = (sum((L12hat_perm[, k])^2) - sum(V[, k])) / sqrt(2 * sum((V[, k])^2))
		}
	return(S)})
	
	confs = apply(abs(res_S), 1, function(x){quantile(x, c(1 - level))})
	return(sum(confs >= S))
}

choose_dimension = function(A, n = dim(A)[1], plot = TRUE) {
    # Choose dimension of z_{12} via screeplot of eigenvalues
    # Codes originated from package rrcovHD, OutlierPCDist.r
    # n is the largest possible dimension

    var.new <- function(x){
        return(if(length(x) == 1) 0 else var(x))
    }

    spec_full = eigen(t(A) %*% A)
    x = spec_full$values[1 : n]
    profile <- rep(0, n)

    for(i in 1:(n - 1))
    {
        x.1 <- x[1:i]
        x.2 <- x[(i+1):n]
        mean.1 <- mean(x.1)
        mean.2 <- mean(x.2)
        var.1 <- var.new(x.1)
        var.2 <- var.new(x.2)
        sd <- ifelse(n <= 2, 1, sqrt(((i-1)*var.1 + (n-i-1)*var.2)/(n-2)))

        profile[i] <- sum(dnorm(x.1,mean.1, sd, log=TRUE)) + sum(dnorm(x.2, mean.2, sd, log=TRUE))
    }
    mean <- mean(x)
    sd <- sd(x)
    profile[n] <- sum(dnorm(x, mean, sd, log=TRUE))
    p <- which(profile == max(profile))

    if(plot){
        plot(spec_full$values[1 : dim(A)[1]], main = paste("d = ", p))
        abline(v = p + 0.5)
    }
    return(p)
}









